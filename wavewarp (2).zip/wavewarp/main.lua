
function main()
    video_src = kmInitVideoSrc()
    src_tex_id = system.video_left.id
    WBFx.setSTexture0(src_tex_id)
	
    
    --Get Aspect Ratio--------
	ar = kmGetOutputWidth() / kmGetOutputHeight()
    ratioX = 1.0
    ratioY = 1.0
    
    if ar > 1.0 then
     ratioY = 1.0 / ar
    elseif ar < 1.0 then
     ratioX = ar
    end
    ---------------------------------
    WBFx.setAspectRatio(ratioX, ratioY)
   
   
	--Variables----------------------
	freq_x = range.x_freq*0.5*0.1 * range.mult_freq
	freq_y = range.y_freq*0.5*0.1 * range.mult_freq
	WBFx.setFreq(freq_x, freq_y)
	
	amp_x = range.x_amp*0.01 * range.strength*0.01
	amp_y = range.y_amp*0.01 * range.strength*0.01
	WBFx.setAmp(amp_x, amp_y)
	
	WBFx.setBOriAlpha(range.bOriAlpha * 1.0)
	WBFx.setOovAlpha(selection.ogTexToggle.x)
	WBFx.setAngle(range.angle)
	WBFx.setWarpAngle(range.warpAngle + 180.0)
	
	wp_x = range.wavePivotX * range.mult_wp*0.01
	wp_y = range.wavePivotY * range.mult_wp*0.01
	WBFx.setWavePivot(wp_x, wp_y)
	
	auto_phase = range.speed * system.play_percentage
	manual_x = range.phaseX*0.5
	manual_y = range.phaseY*0.5
	WBFx.setPhase(auto_phase + manual_x, auto_phase + manual_y)
	
	
	--Damping
	WBFx.setDampAmp(range.damp_amp*0.01)
	WBFx.setDampFreq(range.damp_freq*0.01)
	WBFx.setDampAnch(range.damp_anch*0.01)
    
    
    -- Alpha BG mode
    if selection.ogTexToggle.x == 1.0 then
   	kmSetRenderToDefault()
   	kmClearColor(0.0, 0.0, 0.0, 0.0)
   	kmClear(GL_COLOR_BUFFER_BIT)
    end
    
    
    --Standard-----------------------
	WBFx.setAlpha(effect.alpha)
	WBFx.setColorMatrix(system.video_left.colorconv)
	WBFx.setTexMatrix(system.video_left.texmat)
	WBFx.setMvpMatrix(effect.matrix)
	WBFx.drawScreen(video_src)
    kmReleaseTexture(video_src)
	--created by executable.
end